package p3;

import java.util.Set;
import java.util.TreeSet;

public class SetSortDemo {

	public static void main(String[] args) {

		Set<String> names = new TreeSet<>();

		names.add("Samuel Tigga");
		names.add("Aman Kumar Rastogi");
		names.add("Gyan Punj");
		names.add("Madhu Ramesh");
		names.add("Pranjal Singh");
		names.add("Muskan Gupta");
		names.add("Amit Kumar Yadav");
		names.add("Durga Phukan");
		names.add("Neha Sapalya");
		names.add("Bhargav Mandadi");
		names.add("Piyush Thakur");
		names.add("Kerkere Mallikarjun");

		System.out.println(names);

	}

}
