package p1;

public class Calculator {

	public int sum(int a, int b) {
		return (a + b);
	}
	

	public int division(int a, int b) {
		return (a / b);
	}

}
