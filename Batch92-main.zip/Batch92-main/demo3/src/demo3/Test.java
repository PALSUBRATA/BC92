package demo3;

public class Test {

	public static void main(String[] args) {

		A a1 = new A();

	//	A a2 = new A(5);

	//	A a3 = new A(5, 10);
	}

}
