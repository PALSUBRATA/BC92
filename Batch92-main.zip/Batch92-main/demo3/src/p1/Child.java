package p1;

public class Child extends Parent {
	
	public Child() {
		super();//super call
	}
}
