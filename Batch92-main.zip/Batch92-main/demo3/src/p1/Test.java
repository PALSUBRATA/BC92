package p1;

public class Test {
	
	public static void main(String[] args) {
		
		Child child= new Child();
		
		System.out.println(child.i);
	}

}
