package test;

import p1.Shadab;


public class Test {

	public static void main(String[] args) {
		
		Shadab shad1= new Shadab(); // It should coming from package p1
		p2.Shadab shad2= new p2.Shadab() // It should coming from package p2

		/*
		 * A a1 = new A(); P p = new P(); // Q q = new Q();
		 * 
		 * B b1 = new B();
		 * 
		 * C c1 = new C();
		 */

	}

}
