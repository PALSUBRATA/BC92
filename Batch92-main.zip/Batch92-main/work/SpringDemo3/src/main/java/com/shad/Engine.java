package com.shad;

import org.springframework.stereotype.Component;

@Component
public class Engine {

	void startEngine() {
		System.out.println("Engine is starting...");

	}

}
