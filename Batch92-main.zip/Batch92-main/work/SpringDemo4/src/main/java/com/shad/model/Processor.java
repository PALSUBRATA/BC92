package com.shad.model;

public interface Processor {
	public void start();
}
