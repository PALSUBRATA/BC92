package org.shad.dao;

public class TicketDAO {

	

}
