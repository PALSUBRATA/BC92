public class B
{}